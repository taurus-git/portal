jQuery(document).ready(function ($) {
    //send form data
    $("#submitFormButton").on("click", (function (event) {
        event.preventDefault();

        var position = $("#position-field").val();

        var data = {
            action: 'add_new_position',
            position: position,
        };

        jQuery.post(ajax_name, data, function (response) {
            alert("Success: " + position );
            $("<input name='position' data-positionid='' class='position-input' type='text' value=\"" + position + "\" disabled></<input>" +
                "<button class='edit-save btn btn-outline-info btn-sm' type='button'>Edit</button>").insertAfter(".position-row");
            $("#position-form")[0].reset();
        })
    }));

    //change input value and text on button
    $(".edit-save").on("click", function (event) {
        event.preventDefault();
        var $this = $(this);

        //toggle input status (enabled / disabled)
        var $input = $this.prev();
        if ( $input.prop( "disabled") ) {
            $input.prop( "disabled", false);
            $this.text( 'Save' );
        } else {
            //change class of the button
            $this.addClass( "btn-outline-info btn-outline-primary" );

            //get edited input
            var name = $input.val();
            console.log(name);
            //get position id from data attr
            var id = $input.attr( 'data-positionid' );
            console.log(id);

            var data = {
                action: 'edit_position',
                name: name,
                id: id,
            };
            jQuery.post(ajax_name.url, data, function (response) {
                $input.prop( "disabled", true);
                $this.text( 'Edit' );
            });
        }

    });
});

/*
//remove post
$('#requestTable').on('click', ".deleteQueryButton", function(){
    var post = $(this).closest('.request-row');
    var id = post.attr('id');
    var data = {
        action: 'my_delete_post',
        id: id,
    };

    jQuery.post( ajax_name, data, function(response) {
        alert('Your request deleted');
        post.remove();
    });
});*/
