<?php
/**
 * Add new fields above 'Update' button at user profile.
 *
 * @param WP_User $user User object.
 */
/*
 *
 * USERS SIDE
 *
 * */

function cup_additional_profile_fields( $user ) {
    //Birthday data
    $months 	= array( 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December' );
    $default	= array( 'day' => '', 'month' => '', 'year' => '', );
    $birth_date = wp_parse_args( get_the_author_meta( 'birth_date', $user->ID ), $default );

    ?>
    <h3>Extra profile information</h3>

    <table class="form-table">
        <tr>
            <th><label for="birth-date-day">Birth date:</label></th>
            <td>
                <select id="birth-date-day" name="birth_date[day]"><?php
                    for ( $i = 1; $i <= 31; $i++ ) {
                        printf( '<option value="%1$s" %2$s>%1$s</option>', $i, selected( $birth_date['day'], $i, false ) );
                    }
                    ?></select>
                <select id="birth-date-month" name="birth_date[month]"><?php
                    foreach ( $months as $month ) {
                        printf( '<option value="%1$s" %2$s>%1$s</option>', $month, selected( $birth_date['month'], $month, false ) );
                    }
                    ?></select>
                <select id="birth-date-year" name="birth_date[year]"><?php
                    for ( $i = 1950; $i <= 2015; $i++ ) {
                        printf( '<option value="%1$s" %2$s>%1$s</option>', $i, selected( $birth_date['year'], $i, false ) );
                    }
                    ?></select>
            </td>
        </tr>
        <tr>
            <th><label for="team">Your team:</label></th>
            <td>
                <select id="team" name="team"><?php

                    $args = array(
                        'post_type'      => 'team',
                        'posts_per_page' => 999,
                        'order'          => 'ASC',
                        'orderby'        => 'none',

                    );

                    $query = new WP_Query( $args );

                    if ( $query->have_posts() ) {
                        while ( $query->have_posts() ) {
                            $query->the_post();
                            $this_user_id = get_current_user_id();

                            echo '<option value="'. get_the_ID() .'"'
                                . selected( get_the_ID(), get_user_meta( $this_user_id, 'team', true), false )  . '>'
                                . get_the_title() . '</option>';
                        }
                    } else {
                    }
                    wp_reset_postdata();
                    ?></select>
            </td>
        </tr>
        <tr>
            <th><label for="po">Your Product Owner:</label></th>
            <td>
                <select id="po" name="po"><?php

                    $args = array(
                        'post_type'      => 'po',
                        'posts_per_page' => 999,
                        'order'          => 'ASC',
                        'orderby'        => 'none',
                    );

                    $query = new WP_Query( $args );

                    // The Loop
                    if ( $query->have_posts() ) {
                        while ( $query->have_posts() ) {
                            $query->the_post();
                            $this_user_id = get_current_user_id();

                            echo '<option value="'. get_the_ID() .'"'
                                . selected( get_the_ID(), get_user_meta( $this_user_id, 'po', true), false )  . '>'
                                . get_the_title() . '</option>';
                        }
                    } else {
                    }
                    wp_reset_postdata();
                    ?></select>
            </td>
        </tr>
        <tr>
            <th><label for="floor">Your floor:</label></th>
            <td><?php
                $this_user_id = get_current_user_id();
                echo '<input id="floor" type="number" name="floor" step="1" min="1" max="10" value="' .
                    get_user_meta( $this_user_id, 'floor', true) . '">';
                ?>
            </td>
        </tr>
        <tr>
            <th><label for="position">Your position:</label></th>
            <td><?php
                $positions = json_decode( get_option('position') );
                $this_user_id = get_current_user_id();

                $users_positions_array = array();
                $users_positions_array = get_user_meta($this_user_id, 'position', true);

                foreach ($positions as $position) {
                    if ( empty($users_positions_array) ) {
                        echo '<div>
                                <label>
                                    <input type="checkbox" name="position[]" value="'. $position->id . '">' .
                            $position->name
                            .  '</label>
                              </div>';
                    } else {
                        $users_positions_array_integer = array_map('intval',  $users_positions_array);
                        $checked = ( in_array($position->id, $users_positions_array_integer) ) ? 'checked' : '';
                        echo '<div>
                                <label>
                                    <input type="checkbox" name="position[]" value="'. $position->id . '"' . $checked . '>' .
                                $position->name
                            .  '</label>
                              </div>';
                    }
                }
                ?>
            </td>
        </tr>
    </table>
    <?php
}

add_action( 'show_user_profile', 'cup_additional_profile_fields' );//Добавить свои собственные поля
add_action( 'edit_user_profile', 'cup_additional_profile_fields' );//Добавить свои собственные поля

/**
 * Save additional profile fields.
 * Save data from user profile
 * @param  int $user_id Current user ID.
 */
function cup_save_profile_fields( $user_id ) {

    //add array of checked items by user to db
    $users_positions = array();

    foreach ($_POST['position'] as $check) {
        $users_positions[] = $check;
    }

    update_user_meta($user_id, 'birth_date', $_POST['birth_date']);
    update_user_meta($user_id, 'team', $_POST['team']);
    update_user_meta($user_id, 'po', $_POST['po']);
    update_user_meta($user_id, 'floor', $_POST['floor']);
    update_user_meta($user_id, 'position', $users_positions);

    /*var_dump($some);
    exit;*/
};

add_action( 'personal_options_update', 'cup_save_profile_fields' );
add_action( 'edit_user_profile_update', 'cup_save_profile_fields' );

/*
 *
 * PLUGIN SIDE
 *
 * */

/**
 *Add submenu to Users
 */

function cup_options_page() {
    add_submenu_page(
        'users.php',
        'Positions',
        'Positions',
        'manage_options',
        'cup_positions',
        'cup_positions_options_page_html'
    );
}
add_action('admin_menu', 'cup_options_page');
//Add Bootstrap styles to users.php page
function load_custom_wp_admin_style($users_page_cup_positions) {
    if($users_page_cup_positions != 'users_page_cup_positions') {
        return;
    }
    wp_enqueue_style( 'custom_wp_admin_css', 'https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css' );
}
add_action( 'admin_enqueue_scripts', 'load_custom_wp_admin_style' );

function cup_positions_options_page_html() {?>
    <!--Choose positions -->
    <h2>Add new position:</h2>
    <div style="width: 300px; vertical-align: top;">
        <form id="position-form" action="" method="post">
            <label>
                <input type="text" name="position" id="position-field" value="New position">
            </label>
            <button class="btn btn-success btn btn-primary btn-sm" style="vertical-align: top;" id="submitFormButton" value="Add position"
                    type='button'>Add</button>
            <hr>
            <h4>Existing positions:</h4>
            <?php
            $positions = json_decode( get_option('position') );
            foreach ($positions as $position) {
                echo '<input data-positionid="' . $position->id . '" name="position" class="position-input"
                type="text" value="' . $position->name . '" disabled></input>
                      <button class="edit-save btn btn-outline-info btn-sm" type="button">Edit</button>';
            }
            ?>
            <div class="position-row"></div>
        </form>
    </div>
    <?php
}

/** Register Scripts. */
add_action( 'admin_enqueue_scripts', 'add_cup_scripts', 100 );
function add_cup_scripts() {

    /** Add JavaScript Functions File */
    wp_enqueue_script( 'functions-js', plugins_url('functions.js', __FILE__) , array( 'jquery' ), '1.0', true );

    /** Localize Scripts */
    wp_localize_script( 'functions-js', 'ajax_name', array(
        'url' => admin_url('admin-ajax.php'),
    ) );
}

//send data to db
add_action( 'wp_ajax_add_new_position', 'add_new_position_callback' );
function add_new_position_callback() {
    $positions_array = array();
    $result = get_option('position');

    if( $result ) {
        $result_array = json_decode( $result );
        $result_array_last_key = max(array_column($result_array, 'id'));

        $result_array[] = array('id' => $result_array_last_key + 1, 'name' => $_POST['position']);
        $positions_array = $result_array;
    } else {
        $positions_array[] = array('id' => 0, 'name' => $_POST['position']);
    }

    update_option('position', json_encode($positions_array), 'no');

    wp_die();
};

//edit and save data to db
add_action( 'wp_ajax_edit_position', 'edit_position_callback' );
function edit_position_callback(){
    $result = get_option('position');
    $result_array = json_decode( $result );
    $pos_id = intval($_POST['id']);

    foreach ($result_array as $key => $value) {
        if ($result_array[$key]->id === $pos_id) {
            $result_array[$key]->name = $_POST['name'];
            break;
        }
    };

    update_option('position', json_encode($result_array));
    wp_die();
}