<?php
/*
Plugin Name: Custom User Profile
Plugin URI:
Description:
Version: 0.1
Author: Hyperion Team
Author URI:
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/

// Includes
include ( 'init.php' );
include ( 'settings-page.php' );

// Hooks
add_action( 'init', 'team_init' );
add_action( 'init', 'po_init' );


